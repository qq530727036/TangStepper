#include "stm32f30x.h"
#include "eeprom.h"
#include "step.h"
#define PAGE_ADDR (0x08000000 + 43 * 1024)//(0x08000000 + 63 * 1024)
#define PAGE_ADDR_A (PAGE_ADDR)
#define PAGE_ADDR_B (PAGE_ADDR+ 2046)

uint16_t page_num; //EEPROM������������λ��
/***************************************************************************************************
* ��������: MemReadByte()
* ��������: �Ӵ洢���ж���num�ֽ�����
* ��ڲ���: *dat:�������ݵı����ַ
* num :�������ֽ���
* ���ڲ���: 0������ʧ�ܣ�1�������ɹ�
* ʹ��˵��: ��
* ��������: 2010��12��15��
***************************************************************************************************/
uint8_t MemReadByte(uint16_t *data,uint16_t num)
{
		uint16_t *temp_addr = (uint16_t *)PAGE_ADDR;
		while(num --)
		{
		*data ++ = *temp_addr ++;
		}
		return 1;
}

/***************************************************************************************************
* ��������: MemWriteByte()
* ��������: ��洢����д��num�ֽ�����
* ��ڲ���: *dat:��д������
* num :д����ֽ���
* ���ڲ���: 0������ʧ�ܣ�1�������ɹ�
* ʹ��˵��: ��
* ��������: 2010��12��15��
***************************************************************************************************/
uint8_t MemWriteByte(uint16_t *data,uint16_t num)
{
		FLASH_Status temp_stat;
		uint32_t temp_addr = PAGE_ADDR;

		FLASH_Unlock();													// Flash����������������صļĴ���
		temp_stat = FLASH_ErasePage(PAGE_ADDR); // �����ƶ���ҳ

		if(temp_stat != FLASH_COMPLETE)
		{
			FLASH_Lock();
			return 0;
		}
		while(num --)
		{
			temp_stat = FLASH_ProgramHalfWord(temp_addr,*data);
			if(temp_stat != FLASH_COMPLETE)
			{
				FLASH_Lock();
				return 0;
			}
			temp_addr += 2;
			data++;
		}
		FLASH_Lock();
		return 1;
}

//uint16_t write_buf[10] = {0,1,2,3,4,5,6,7,8,9};
//void eeprom_test(void)
//{
////	uint8_t cnt;
////	//MemWriteByte(write_buf,10);
////	for(cnt = 0;cnt < 10;cnt++) write_buf[cnt] = 11;

////	MemReadByte(write_buf,10);
//uint32_t eeprom_addr;
//uint16_t *temp_addr;
//	eeprom_addr = PAGE_ADDR_B;
////uint16_t data;
//	FLASH_Unlock();
//	//��дҳ��
//	FLASH_ErasePage(eeprom_addr);
//	FLASH_ProgramHalfWord(eeprom_addr,0xaa55);	//д���

//	FLASH_Lock();

//		eeprom_addr = PAGE_ADDR_B;
//		temp_addr = (uint16_t *)eeprom_addr;

//		data = *temp_addr++;

//eeprom_addr = PAGE_ADDR_A;
//	FLASH_Unlock();
//	//��дҳ��
//	FLASH_ErasePage(eeprom_addr);

//	FLASH_Lock();

//temp_addr = (uint16_t *)PAGE_ADDR_B;
//data = *temp_addr++;
//__NOP();
//}

uint8_t EEROM_init(uint16_t *val,uint16_t num)
{
	uint8_t i;
	uint16_t *temp_addr;
	uint16_t data;
	for(i = 0;i < 5;i++)
	{
		//eeprom_addr = PAGE_ADDR + (i * 2048);
		temp_addr = (uint16_t *)(PAGE_ADDR + (i * 2048));
		data = *temp_addr++;
		if(data == 0xaa55) //�Ƿ���в���
		{
			//��������
			page_num = i;
			while(num --)
			{
				*val ++ = *temp_addr ++;
			}
			return 1;
		}
	}
	if(i >= 5)
	{
		//Ĭ�ϲ���
		return 0;
	}
	return 0;
}



uint8_t WriteEEPROM(uint16_t *data,uint16_t num)
{
	//����ҳд����
	uint16_t *buf = data;
	uint16_t page = page_num + 1;		
	uint32_t eeprom_addr;
	uint16_t i = num;
	if(page >= 5) page = 0; 
	eeprom_addr = PAGE_ADDR + (page * 2048);
	FLASH_Unlock();
	//��дҳ��
	FLASH_ErasePage(eeprom_addr);
	FLASH_ProgramHalfWord(eeprom_addr,0xaa55);	//д���
	while(i--)		//д����
	{
		eeprom_addr += 2;
		FLASH_ProgramHalfWord(eeprom_addr,*buf);		
		buf++;
	}
	FLASH_Lock();

	//��֤����
	{
		uint8_t err;
		uint16_t r_data[64];
		uint16_t *temp_addr;
		buf = data;
		eeprom_addr = PAGE_ADDR + (page * 2048);
		temp_addr = (uint16_t *)eeprom_addr;

		for(i = 0;i < num;i++)
		{
			r_data[i] = *temp_addr++;
		}
		err = 0;
		if(r_data[0] == 0xaa55)
		{
				for(i = 1;i < num;i++)
				{
					if(*buf++ !=r_data[i])
					{
						err = 1;
						break;
					}
				}
		}
		else err = 2;

		if(err != 0) 
		{
			if(err == 2) 
			{
				FLASH_Unlock();
				//��дҳ��
				FLASH_ErasePage(eeprom_addr);
				FLASH_Lock();
				return 0;
			}
			return 0;
		}
		else
		{
			eeprom_addr = PAGE_ADDR + (page_num * 2048);
			FLASH_Unlock();
			//��дҳ��
			FLASH_ErasePage(eeprom_addr);
			FLASH_Lock();

			page_num = page;
			return 1;
		}
		

	}
	

}



void ReadEEPROMData(void)
{
	uint8_t temp;
	uint16_t buf[20];
	temp = EEROM_init(buf,20);
	if(temp == 0)
	{
		//��дĬ������
		motor.step_mode = STEP_128MIC;
		motor.decay = MIXED_DECAY;
		motor.dir = 0;
//		motor.pin_enter_time = 0;
//		motor.step_sync = 0;
//		motor.servo = SERVO_ON;

		motor.min_speed = 1;
		motor.max_speed = 20;
		
		motor.max_step_error = 1;
		motor.min_step_error = 0;

		motor.max_current = 	0x8ff;
		motor.min_current  =	500;
		motor.accel = 0;		
		motor.in_mode = 0;
		motor.max_step  =  0xfffffff0;
		motor.min_step 	=  0;	
		
		motor.min_speed = 2;
		motor.max_speed = 20;

		motor.step_mode = STEP_128MIC;
		motor.decay 		= MIXED_DECAY;
		motor.dir 			= 0;	
		motor.ent				= 1;
		
		motor.addr = 0;
		motor.baud = 6;
	}
	else
	{
		motor.max_current = buf[0];
		motor.min_current  = buf[1];
		motor.accel = buf[2];
		motor.in_mode = buf[3];
		motor.max_step  	= ((uint32_t)buf[4] << 16) | (buf[5]);
		motor.min_step 	= ((uint32_t)buf[6] << 16) | (buf[7]);

		motor.min_speed = buf[8];
		motor.max_speed = buf[9];

		motor.step_mode = buf[10] & 0x3;
		motor.decay 		= (buf[10]>>2) & 0x3;
		motor.dir 			= (buf[10]>>4) & 0x1;
		motor.ent 			= (buf[10]>>5) & 0x1;
		
		
		motor.min_step_error = buf[11] & 0xff;
		motor.max_step_error = (buf[11] & 0xff) >> 8;
		
//		motor.pin_enter_time = 0;
//		motor.step_sync = 0;
//		motor.servo = SERVO_ON;
		motor.addr = buf[19] & 0xff;
		motor.baud = (buf[19] >> 8);
		if(motor.addr > 0xf0) motor.addr = 0;
		if(motor.baud >= 10) 	motor.baud = 6;

	}
	motor_set_microsteps(motor.step_mode,motor.decay); //���ģʽ����
}

void WriteEEPROMData(void)
{
	uint16_t buf[20];
	uint8_t error;
	
	step.status |= ST_EEPROM;		//дEEPROM
	
	buf[0] = motor.max_current;
	buf[1] = motor.min_current;
	buf[2] = motor.accel;
	buf[3] = motor.in_mode;
	buf[4] = motor.max_step >> 16;
	buf[5] = motor.max_step & 0xffff;
	buf[6] = motor.min_step >> 16;
	buf[7] = motor.min_step & 0xffff;						
	buf[8] = motor.min_speed;
	buf[9] = motor.max_speed;
	buf[10] = 0;
	buf[10] = motor.step_mode & 0x3;
	buf[10] |= (motor.decay & 0x3) << 2;
	buf[10] |= (motor.dir & 0x1) << 4;
	buf[10] |= (motor.ent & 0x1) << 5;
	buf[11] = motor.min_step_error & 0xff;
	buf[11] |= (motor.max_step_error & 0xff) << 8;	
	
	buf[19] = 0;
	buf[19] = motor.addr;
	buf[19] |= motor.baud << 8;

	error = WriteEEPROM(buf,20);
	
	step.status &= ~ST_EEPROM;
	if(error == 0) //дEEP����
	{
		//err.eeprom = 1;		
		step.status |= ST_EEP_ERR;
	}
	else
	{
		//err.eeprom = 0;	
		step.status &= ~ST_EEP_ERR;
		motor_set_microsteps(motor.step_mode,motor.decay); //���ģʽ����
	}
}

