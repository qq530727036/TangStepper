#include "stm32f30x.h"

/* SSP Status register */
#define SSPSR_TFE       (0x1<<0)
#define SSPSR_TNF       (0x1<<1) 
#define SSPSR_RNE       (0x1<<2)
#define SSPSR_RFF       (0x1<<3) 
#define SSPSR_BSY       (0x1<<4)


void  AS5047_SPI_Init (void)
{
	SPI_InitTypeDef  SPI_InitStructure;
	
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3, ENABLE);// ʹ��SPI1ʱ��

	SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;  //����SPIȫ˫��
	SPI_InitStructure.SPI_Mode = SPI_Mode_Master;        //����SPI����ģʽ:��SPI
	SPI_InitStructure.SPI_DataSize = SPI_DataSize_16b;     //����SPI�����ݴ�С: 8λ֡�ṹ
	SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;//����ͬ��ʱ�ӵĿ���״̬Ϊ�ߵ�ƽ
	SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge; //���ݲ����ڵڶ���ʱ����
	SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;   //NSS�ź���Ӳ������
	SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8;    //Ԥ��Ƶ256
	SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB; //���ݴ����MSBλ��ʼ
	SPI_InitStructure.SPI_CRCPolynomial = 7;    //CRCֵ����Ķ���ʽ
	SPI_Init(SPI3, &SPI_InitStructure); //����ָ���Ĳ�����ʼ������SPIx�Ĵ���
	SPI_RxFIFOThresholdConfig(SPI3, SPI_RxFIFOThreshold_QF); 
	SPI_Cmd(SPI3, ENABLE); //ʹ��SPI1
	
	GPIOA->BSRR = GPIO_Pin_15;
}



uint16_t SSP_Receive(void)
{
	GPIOA->BRR = GPIO_Pin_15;
  while (SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_TXE) == RESET);
  SPI_I2S_SendData16(SPI3, 0xffff);
  while (SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_RXNE) == RESET);	
	GPIOA->BSRR = GPIO_Pin_15;
  return SPI_I2S_ReceiveData16(SPI3);
}


uint16_t SSP_Read_reg(uint16_t reg_add)
{
	GPIOA->BRR = GPIO_Pin_15;
  while (SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_TXE) == RESET);
  SPI_I2S_SendData16(SPI3, 0xffff);
  while (SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_RXNE) == RESET);	
	GPIOA->BSRR = GPIO_Pin_15;
  return SPI_I2S_ReceiveData16(SPI3);
}
//uint16_t SSP_Read_reg(uint16_t reg_add)
//{
//	uint8_t i;
//	GPIOA->BRR = GPIO_Pin_15;
//  while (SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_TXE) == RESET);
//  SPI_I2S_SendData16(SPI3, reg_add);
//  while (SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_RXNE) == RESET);	
//	GPIOA->BSRR = GPIO_Pin_15;
//	for(i = 0;i < 100;i++) __NOP();
//	GPIOA->BRR = GPIO_Pin_15;
//  while (SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_TXE) == RESET);
//  SPI_I2S_SendData16(SPI3, 0xffff);
//  while (SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_RXNE) == RESET);	
//	GPIOA->BSRR = GPIO_Pin_15;
//  return SPI_I2S_ReceiveData16(SPI3);
//}

uint32_t SecondFilterI(uint32_t data)
{
	static float OldData;	
	OldData = ((data * 20) + (OldData * 80))/100;
	return(OldData);	
}

int get_angle(uint8_t dir)
{
		uint16_t dat;
		//uint32_t out1;
		dat = SSP_Receive() & 0x3fff;
		dat >>= 4;
		//out1 = SecondFilterI((uint32_t)dat);
	
		//if(dir) return (-out1);
		//else 		return (out1);
		return(dat);
}
