
#include "buf.h"
#include "step.h"
#include <math.h>
//#include "buf.h"
#define ON 1;
#define OFF 0;

float_byte_un float_byte;
uint32_byte_uni uint32_byte;
uint16_byte_uni uint16_byte;
int32_byte_uni int32_byte;
int16_byte_uni int16_byte;

//error_str err;
motor_str motor;
step_str 	step;


buf_str *current_block;	
int step_event_count;
int current_step;			
int count_direction; //����
int count_position = 0; //��������
int step_events_completed;//���¼�����
int counter_x;

//#define Rrfx = 0.47
//#define Iout = Vref/(5*Rrfx) = Vref / 2.35V


void motor_set_microsteps(uint8_t segme,uint8_t decay);

//����������״̬
//uint8_t step_read_state(void)
//{

//	uint8_t state = 0;
//	if(step.start != 0) state |= STEP_STATE_START;
//	if(step.suspend != 0) 	state |= STEP_STATE_SUSPEND;
//	if(step.home != 0) 	state |= STEP_STATE_HOME;
//	if(step.stop != 0)  state |= STEP_STATE_STOP;
//	if(step.booster != 0) state |= STEP_STATE_BOOSTER;
//	return state;
//	
//}
//������ʼ
//void step_start(void)
//{
//	if(step.home == 0)
//	{
//		step.suspend 	= 0;
//		step.start = 1;
//		step.stop = 0;
//		
//		step.step_target = step.target;
//		
//		SEP_ENB(0);
//	}
//}

//������ͣ
//void step_suspend(void)
//{
//	if(step.start != 0)
//	{
//		step.suspend 	= 1;
//		step.start 	= 0;
//		step.home = 0;
//		step.step_target = step.step_current;
//		
//	}

//}
//����ֹͣ
//void step_stop(void)
//{
//		step.stop = 1;
//		step.target = 0;
//		step.speed = 0;
//		step.total = 0;
//		step.start = 0;
//		step.suspend 	= 0;
//		step.start 	= 0;
//		step.home = 0;	
//		step.booster = 0;
//		step.step_target = step.step_current;
//		step.target = step.step_current;
//		SEP_ENB(1);
//	
//}

//void step_home(void)
//{
//	if(step.start == 0)
//	{
//		//step.home = 1;
//		step.suspend = 0;
//	}
//}
//�ֶ��ƶ�
//void step_booster(void)
//{
//	if(step.start == 0)
//	{
//		step.booster = 1;
//		step.suspend = 0;
//	}
//}

//�������ݸ�ֵ
void step_data_in(int32_t target,int32_t speed_total)
{
	//step.target = target;
	//if(motor.step_sync !=0) step.total = speed_total;
	//else 										step.speed = speed_total;
	
}
//����������ֵ
void step_data_out(int32_t *target,int32_t *speed_total)
{
	*target = step.target;
	if(motor.step_sync !=0) *speed_total = step.total;
	else 										*speed_total = step.speed;
}

uint8_t motor_get_data_len(void)
{
	return MOTOR_DATA_MAX;
}

//�޸Ĳ���
uint8_t motor_set_data(uint8_t *buf,uint8_t len)
{
	//if(step.stop == 0) return;				//ֹͣ״̬�²���д����
	if(MOTOR_DATA_MAX == len)
	{
		motor.step_mode = *buf;
		motor.decay 		= *(buf+1);
		motor.dir 			= *(buf+2);
		motor.pin_enter_time = *(buf+3);
		motor.step_sync = *(buf+4);
		//motor.current 	= *(buf+5);
		motor.servo 		= *(buf+6);
//		int16_byte.byte[0] =	*(buf+7);
//		int16_byte.byte[1] = 	*(buf+8);
//		motor.Kp = int16_byte.int16Temp;
//		int16_byte.byte[0] =	*(buf+9);
//		int16_byte.byte[1] = 	*(buf+10);		
//		motor.Ki = int16_byte.int16Temp;
//		int16_byte.byte[0] =	*(buf+11);
//		int16_byte.byte[1] = 	*(buf+12);			
//		motor.Kd = int16_byte.int16Temp;;
		
		uint16_byte.byte[0] =	*(buf+13);
		uint16_byte.byte[1] = *(buf+14);			
		motor.min_speed = uint16_byte.uint16Temp;
		uint16_byte.byte[0] =	*(buf+15);
		uint16_byte.byte[1] = *(buf+16);
		motor.max_speed = uint16_byte.uint16Temp;
		
		motor_default_ro_save_value(MOTOR_DATA_SAVE);
		
		motor_set_microsteps(motor.step_mode,motor.decay);
		return MOTOR_DATA_MAX;
	}
	else
	{
		return 0;
	}
	
	
}

//�����������
uint8_t motor_read_data(uint8_t *buf,uint8_t len)
{
	if(MOTOR_DATA_MAX == len)
	{
		*buf 			= motor.step_mode;
		*(buf+1) 	= motor.decay;
		*(buf+2) 	= motor.dir;
		*(buf+3) 	= motor.pin_enter_time;
		*(buf+4) 	= motor.step_sync;
		//*(buf+5) 	= motor.current;
		*(buf+6) 	= motor.servo;
//		int16_byte.int16Temp = motor.Kp;
//		*(buf+7) 	= int16_byte.byte[0];	
//		*(buf+8)  = int16_byte.byte[1];
//		int16_byte.int16Temp = motor.Ki;
//		*(buf+9)	= int16_byte.byte[0];
//		*(buf+10) = int16_byte.byte[1];
//		int16_byte.int16Temp = motor.Kd;
		*(buf+11) = int16_byte.byte[0];
		*(buf+12) = int16_byte.byte[1];	
		uint16_byte.uint16Temp = motor.min_speed;
		*(buf+13) = uint16_byte.byte[0];
		*(buf+14) = uint16_byte.byte[1];	
		uint16_byte.uint16Temp = motor.max_speed;
		*(buf+15) = uint16_byte.byte[0];
		*(buf+16) = uint16_byte.byte[1];	
		return MOTOR_DATA_MAX;
	}
	else
	{
		return 0;
	}
}


//������������ָ�Ĭ��.
#define MOTOR_DATA_DEFAULT		1
#define MOTOR_DATA_SAVE			  0
void motor_default_ro_save_value(uint8_t operation)
{
	if(operation == MOTOR_DATA_DEFAULT)
	{
		motor.step_mode = STEP_128MIC;//STEP_64MIC;//STEP_128MIC;
		motor.decay = MIXED_DECAY;
		motor.dir = 0;
		motor.pin_enter_time = 0;
		motor.step_sync = OFF;
		//motor.current = 100;
		motor.servo = SERVO_ON;
//		motor.Kp = 0.005;
//		motor.Ki = 0.00000001;
//		motor.Kd = 0.00002;
		
		motor.min_speed = 1;
		motor.max_speed = 20;
	}
	
	
	//if(motor.step_mode > STEP_128MIC)  	motor.step_mode = STEP_32MIC;
	if(motor.decay > MIXED_DECAY) 			motor.decay = MIXED_DECAY;
	if(motor.dir >  1) 									motor.dir = 1;
	if(motor.pin_enter_time > 250) 			motor.pin_enter_time = 250;
	if(motor.step_sync > 1) 						motor.step_sync = 1;
	//if(motor.current > 100) 						motor.current = 100;
//	if(motor.servo > 1)									motor.servo = 1;
//	if(motor.Kp > 10000)								motor.Kp = 10000;
//	else if(motor.Kp < 0) 							motor.Kp = 0;
//	if(motor.Ki > 10000)								motor.Ki = 10000;
//	else if(motor.Ki < 0) 							motor.Ki = 0;
//	if(motor.Kd > 10000)								motor.Kd = 10000;
//	else if(motor.Kd < 0) 							motor.Kd = 0;
//	if(motor.max_speed > 10000)					motor.max_speed = 10000;
//	if(motor.min_speed > motor.max_speed) motor.min_speed = motor.max_speed - 1;
//	
//	I2CMasterBuffer[0] = motor.step_mode;
//	I2CMasterBuffer[1] = motor.decay;
//	I2CMasterBuffer[2] = motor.dir;
//	I2CMasterBuffer[3] = motor.pin_enter_time;
//	I2CMasterBuffer[4] = motor.step_sync;
//	I2CMasterBuffer[5] = motor.current;
//	I2CMasterBuffer[6] = motor.servo;
//	int16_byte.int16Temp = motor.Kp;
//	I2CMasterBuffer[7] = int16_byte.byte[0];
//	EEPROM_WData(EEP_MOVE_DATA,8);
//	EEPROM_w_delay();
//	I2CMasterBuffer[0] = int16_byte.byte[1];
//	int16_byte.int16Temp = motor.Ki;
//	I2CMasterBuffer[1] = int16_byte.byte[0];
//	I2CMasterBuffer[2] = int16_byte.byte[1];
//	int16_byte.int16Temp = motor.Kd;
//	I2CMasterBuffer[3] = int16_byte.byte[0];
//	I2CMasterBuffer[4] = int16_byte.byte[1];	
//	uint16_byte.uint16Temp = motor.min_speed;
//	I2CMasterBuffer[5] = uint16_byte.byte[0];
//	I2CMasterBuffer[6] = uint16_byte.byte[1];	
//	uint16_byte.uint16Temp = motor.max_speed;
//	I2CMasterBuffer[7] = uint16_byte.byte[0];
//	EEPROM_WData(EEP_MOVE_DATA+8,8);
//	EEPROM_w_delay();
//	I2CMasterBuffer[0] = uint16_byte.byte[1];	
//	EEPROM_WData(EEP_MOVE_DATA+16,1);
//	
//	
//	EEPROM_w_delay();
//	I2CMasterBuffer[0] = 0xaa;
//	I2CMasterBuffer[1] = 0x55;
//	EEPROM_WData(EEP_SYS_DATA,2);
//	
	
}



//��ʱ����ʼ��
void T1_Init(void)             
{
//	uint16_t i;
	

//         LPC_SYSCON->SYSAHBCLKCTRL |= (1<<10);     				//�򿪹���ʱ��
//         LPC_TMR32B1->TCR		=0x02;                       //��λ��ʱ��
//         LPC_TMR32B1->MR0   =100;                       
//         LPC_TMR32B1->PR    =48;                         //��Ƶ,48000000/48 = 1us
//				LPC_TMR32B1->MCR 		= (3<<0);                      //MR3��TCƥ��ʱTC��λ
//	
//				LPC_TMR32B1->IR 	= 0;   										//��λ�жϱ�־
//				LPC_TMR32B1->TCR 	= 0x0001;									//�򿪶�ʱ��	
//				NVIC_EnableIRQ(TIMER_32_1_IRQn);
//	
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
		NVIC_InitTypeDef NVIC_InitStructure; 

	
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6 , ENABLE);
    TIM_DeInit(TIM6);
    TIM_TimeBaseStructure.TIM_Period=300;//1000;		 /* �Զ���װ�ؼĴ������ڵ�ֵ(����ֵ) */
    /* �ۼ� TIM_Period��Ƶ�ʺ����һ�����»����ж� */
    TIM_TimeBaseStructure.TIM_Prescaler= 1;//(22500 - 1);	/* ʱ��Ԥ��Ƶ�� (180M/8)/22500 */
    TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1; 		/* ������Ƶ */
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; /* ���ϼ���ģʽ */
    TIM_TimeBaseInit(TIM6, &TIM_TimeBaseStructure);
    TIM_ClearFlag(TIM6, TIM_FLAG_Update);							/* �������жϱ�־ */
    TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE);
    TIM_Cmd(TIM6, ENABLE);														/* ����ʱ�� */    
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6 , DISABLE);		/* �ȹرյȴ�ʹ�� */  	
		
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);  													
    NVIC_InitStructure.NVIC_IRQChannel = TIM6_DAC_IRQn;//TIM1_UP_TIM16_IRQn;	  
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);		
		
		
		


	
//    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM15 , ENABLE);
//    TIM_DeInit(TIM15);
//    TIM_TimeBaseStructure.TIM_Period=500;//1000;		 /* �Զ���װ�ؼĴ������ڵ�ֵ(����ֵ) */
//    /* �ۼ� TIM_Period��Ƶ�ʺ����һ�����»����ж� */
//    TIM_TimeBaseStructure.TIM_Prescaler= 72;//(22500 - 1);	/* ʱ��Ԥ��Ƶ�� (180M/8)/22500 */
//    TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1; 		/* ������Ƶ */
//    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; /* ���ϼ���ģʽ */
//    TIM_TimeBaseInit(TIM15, &TIM_TimeBaseStructure);
//    TIM_ClearFlag(TIM15, TIM_FLAG_Update);							/* �������жϱ�־ */
//    TIM_ITConfig(TIM15,TIM_IT_Update,ENABLE);
//    TIM_Cmd(TIM15, ENABLE);														/* ����ʱ�� */    
//    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM15 , DISABLE);		/* �ȹرյȴ�ʹ�� */  	
//		
//    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3);  													
//    NVIC_InitStructure.NVIC_IRQChannel = TIM1_BRK_TIM15_IRQn;//TIM1_UP_TIM16_IRQn;	  
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_Init(&NVIC_InitStructure);				
//		
//		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM15 , ENABLE);	

}


//����ͨ��1�����ѹ
//vol:0~3300,����0~3.3V
//void Dac1_Set_Vol(u16 vol)
//{
//       double temp=vol;
//       temp/=1000;
//       temp=temp*4096/3.3;
//       DAC_SetChannel1Data(DAC1,DAC_Align_12b_R,temp);//12λ�Ҷ������ݸ�ʽ
//}


//ͬ���ź������ʼ��
void Sync_Init(void)
{
//	S485_RO_DIR_IN() 	;
//	S485_NRE_DIR_OUT();
//	S485_RX_DIR_IN() 	;
//	S485_TX_DIR_OUT() ;
//	
//	S485_NRE(0);			//ֻ���ڶ�ͬ���ź�
//	S485_TX(1);				//Ĭ������ߵ�ƽ
//	
//	NVIC_EnableIRQ(EINT0_IRQn);

//	LPC_GPIO0->IS 	&= ~(0x1 << 2);	//���ش���
//	LPC_GPIO0->IBE	&= ~(0X1 << 2); //��IEV���ƹܽ��ж�
//	LPC_GPIO0->IEV 	|= (0X1 << 2);	//�½����ж�

//	LPC_GPIO0->IE 	|= (0X1 << 2);		//���ж�
}


void motor_io_init(void)
{
	
		DAC_InitTypeDef DAC_InitType;
		//DA
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);//��ʹ��DACʱ��
		DAC_InitType.DAC_Trigger=DAC_Trigger_None; //��ʹ�ô������� TEN1=0
		DAC_InitType.DAC_WaveGeneration=DAC_WaveGeneration_None;//��ʹ�ò��η���
		DAC_InitType.DAC_LFSRUnmask_TriangleAmplitude=DAC_LFSRUnmask_Bit0;
		//���Ρ���ֵ����
		DAC_InitType.DAC_Buffer_Switch=DAC_BufferSwitch_Disable ;//�������ر�
		DAC_Init(DAC1,DAC_Channel_1,&DAC_InitType); //�۳�ʼ��DACͨ��1

		DAC_Cmd(DAC1,DAC_Channel_1, ENABLE);  //��ʹ��DACͨ��1
		DAC_SetChannel1Data(DAC1,DAC_Align_12b_R, 0);  //��12λ�Ҷ������ݸ�ʽ		
		
		
	if(motor.ent) 
	{
		SEP_ENB(1);
		step.servo = 1;
	}
	else
	{
		step.servo = 0;
		SEP_ENB(0);
	}
	
	
	SEP_STEP(0);
	motor_set_microsteps(motor.step_mode,motor.decay);
	
	Sync_Init();
	
	T1_Init();
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6 , ENABLE);		/* ʹ�� */  	
}


//��������
void sep_dir(uint8_t dir)
{
		if(motor.dir == 0)
		{
			if(dir == 0) 	{SEP_DIR(0);}
			else					{SEP_DIR(1);}
		}
		else
		{
			if(dir == 0) 	{SEP_DIR(1);}
			else					{SEP_DIR(0);}
		}
}


//�����Ƶ��ʽ,�������˥��
//�����Ƶ��ʽ,�������˥��
void motor_set_microsteps(uint8_t segme,uint8_t decay)
{

		if(decay != 0)  SEP_FDT(1);
		else 						SEP_FDT(0);	

		switch(segme)
		{
			case 0:
				SEP_MO1(0);SEP_MO0(0);
				break;
			case 1:
				SEP_MO1(0);SEP_MO0(1);
				break;
			case 2:
				SEP_MO1(1);SEP_MO0(0);
				break;
			case 3:
				SEP_MO1(1);SEP_MO0(1);
				break;
			
		}
}


void motor_set_decay(uint8_t decay_mode)
{
	if(READ_ENB_PIN() == 0) //û������ʱ����������
	{
		if(decay_mode == 0) 			SEP_FDT(0);	//slow decay
		else if(decay_mode == 1) 	SEP_FDT(1);	//fast decay
		else if(decay_mode == 3)	 							//mixed decay 
		SEP_REST(0);
		__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();
		__NOP();__NOP();__NOP();__NOP();__NOP();
		SEP_REST(1);
	}
}
 


void motor_test(int32_t step,uint32_t speed)
{
	int32_t i;
	uint32_t j;
	//SEP_ENB(0);
	if(step == 0) return;	
	else if(step < 0) 
	{
		step = -step;
		SEP_DIR(0);
	}
	else  
	{
		SEP_DIR(1);
	}
	
	for(i = step;i > 0;i--)
	{
		SEP_STEP(1);
		for(j = 0;j < speed;j++);
		SEP_STEP(0);
		for(j = 0;j < speed;j++);
	}
	//SEP_ENB(1);
}



int ang_val = 0;
int out;
int32_t raw_0,raw_1;
float ang;
int y;
int step_target = 0;
// int Kp = 5000;
// int Ki = 4;
// int Kd = 10;


// const float iMAX = 1.0;
// const float rSense = 0.150;
// volatile int uMAX = (1023/3.3)*(iMAX*10*rSense);
void delay(void)
{
	uint16_t j;
	for(j = 0;j < 50;j++);
}

//ʸ������
//int su,er = 0;
//int old_val = 0;
//int dr = 0;
//int dr_old=0;
//int32_t  arrow(int32_t val)
//{
//	er =val - old_val;
//	su = su + er;
//	if(su > 50) {dr = 1; su = 0;}
//	else if(su < -50) {dr = 2;su = 0;}
//	
////	if(dr_old != dr)
////	{
////		dr_old = dr;
////	}
//	
//	if((old_val < val) && (dr == 1)) 
//	{
//		old_val = val;		
//	}
//	if((old_val > val) && (dr == 2)) 
//	{
//		old_val = val;		
//	}		
//		
//	return old_val;
//	
//	
//}

int u;
extern uint16_t ang_val_temp;
int get_angle(uint8_t);



extern uint32_t target;


uint32_t A_MAX=0,A_MIN=0;
volatile long I_val;
int ang_val_tp = 0;

extern uint8_t  sw;
uint16_t count_sp=0;
uint16_t count_sp_max=10;
void tg(void);

extern int32_t step_ ;
extern int32_t sheep;
uint16_t a_v;

int32_t sheep = 2;

int I_MAX_ = 200;
long PTerm,DTerm,ITerm=0;
int e_0;
volatile int Kp =100;//20000;    // proportional constan
volatile int Ki = 1;    // integrational constant
volatile int Kd = 0; // differential constant

void delay1(void)
{
	
	int32_t i;
	
	for(i=0;i< 2;i++); //200in16��Ƶ,90in32��Ƶ,50in62��Ƶ,25in128
	
}


void TIM6_DAC_IRQHandler(void)//TIM1_UP_TIM16_IRQHandler(void)
{
	int e;
	int raw_diff;
	static int32_t step_target_old = 0;

	if(TIM_GetITStatus(TIM6,TIM_IT_Update)==SET) //����ж�
	{
		TIM_ClearITPendingBit(TIM6,TIM_IT_Update);  //����жϱ�־λ


//			count_sp++;
//			if(count_sp > count_sp_max)
//			{
//				count_sp=0;
//				tg();
//			}
		//SEP_STEP(0);
		ang_val = TIM_GetCounter(TIM2);
		if(motor.dir != 0) ang_val = -ang_val; //��������
		//ang_val = arrow(ang_val_tp);
//		if(A_MAX < ang_val) 
//		{
//			A_MAX = ang_val;
//		}
//		else
//		{
//			if(ang_val < 1000) A_MAX = 0;
//		}
//		if(A_MIN > ang_val) 
//		{
//			A_MIN = ang_val;
//		}
//		else
//		{
//			if(ang_val > 3000) A_MIN = 1111;
//		}
		
		#define circle 2000
		#define semicircle 1000
			
		if(step.zero == 0) 	//�������������á�
		{
			raw_0 = (ang_val) ;																							//���㵱ǰ�Ƕ�
			raw_diff = raw_0 - raw_1;
			if (raw_diff < -semicircle) 		y = y + circle + raw_diff;      //��һȦ 							  	ԭ��360��0 Ϊ��Ȧ��¼��0��360Ϊ��һȦ��
			else if (raw_diff > semicircle) y = y - circle + raw_diff;			//��һȦ
			else y = y + raw_diff;				
			step.step_current  = y;
		}
		else
		{
			step.step_current  =  0;
			step.step_target   =  0;
			raw_0 = 0;
			step.zero = 0;
		}		
		raw_1 = raw_0;

		//PID
		e_0 = step.step_target - y;
		PTerm = (Kp * e_0);
 		ITerm += (Ki * e_0);  // ITerm = ITerm + e_0;
		//#define I_MAX 40000
 		if(ITerm > I_MAX_)			  ITerm = I_MAX_;
 		else if(ITerm < -I_MAX_) ITerm = -I_MAX_;		
		u = (PTerm + ITerm)/100;
		

		e = step.step_target - y;
		//u = e;

		if(e > 0) {sep_dir(1);step.dir = 1;}		//��ƫ��ֵѡ����
		else 			{sep_dir(0);step.dir = 0;}
		
		if(u < 0)	u = -u;
		#define uMAX 200
		if(u > uMAX)  			u= uMAX;	
		step_ = e;
		
		//if((20 - u) < 2) sheep = 2;
		//else sheep = 20 - u;
		if((motor.max_speed - u) < motor.min_speed) sheep = motor.min_speed;
		else sheep = motor.max_speed - u;
		
		a_v = u;
		if(a_v > motor.max_current)  			a_v = motor.max_current;
		else if(a_v < motor.min_current) 	a_v = motor.min_current;

			 
		if((step_ > motor.max_step_error) || (step_ < -motor.min_step_error) || (step_target_old != step.step_target))
		{
			step_target_old = step.step_target;
			step.status &= ~ST_TARGET;	//δ�ﵽĿ��ֵ
			if((((R_LIMIT == 0)&&(step.dir == 0)) || ((L_LIMIT == 0)&&(step.dir !=0))) && step.servo && (step.stop == 0)) //��λ���,�ŷ��򿪼��
			{							
				DAC_SetChannel1Data(DAC1,DAC_Align_12b_R,a_v);	
				SEP_STEP(1);
				//delay1();
				//SEP_STEP(0);
			}
			else
			{

				DAC_SetChannel1Data(DAC1,DAC_Align_12b_R,motor.min_current);	
			}
		}		
		else
		{
			DAC_SetChannel1Data(DAC1,DAC_Align_12b_R,motor.min_current);	
			SEP_STEP(0);
			step.status |= ST_TARGET;	//����Ŀ��ֵ���
			__NOP();
		}

		SEP_STEP(0);
					
	}
}

//ͬ���ź��ж�
//void PIOINT0_IRQHandler(void)
//{
//	//uint8_t j;
//	
//  //ͬ���ź�
//  if(LPC_GPIO0->MIS & (0X1 << 2)) 
//  {
//		LPC_GPIO0->IC |= (0X1 << 2); //���жϱ��

//		if(current_block == 0)
//		{
//			current_block = serial_read();
//			current_step 	   = (current_block->step)	;				
//			step_event_count = (current_block->step_all);
//			if(current_step < 0)
//			{
//				current_step = -current_step;
//				count_direction = -1;
//			}
//			else 
//			{
//				count_direction = 1;
//			}
//			counter_x = -(step_event_count >> 1);
//			step_events_completed = 0;
//		//
//		}
//		
//		if (current_block != 0) 
//		{
//        counter_x += current_step;
//        if (counter_x > 0) 
//				{
//          counter_x -= step_event_count;
//          step.step_target +=count_direction;   
//					
//        }		
//				
//				step_events_completed++;
//				if(step_events_completed >= step_event_count)
//				{
//					current_block = 0;
//				}
//		}

//  }
//}



//void TIM1_BRK_TIM15_IRQHandler(void)//TIM1_UP_TIM16_IRQHandler(void)
//{
//	//static uint8_t count=0,ck = 0;
//	//uint8_t i;
//	//static int e_1 = 0;
//	//static int e_2 = 0;
//	//int raw_diff;
//	

//	
////	float ang_temp;
//	if(TIM_GetITStatus(TIM15,TIM_IT_Update)==SET) //����ж�
//	{
//		TIM_ClearITPendingBit(TIM15,TIM_IT_Update);  //����жϱ�־λ
//		__NOP();
//	}
//	
//}

int32_t get_step_target(void)
{
	return(step.step_target);
}


