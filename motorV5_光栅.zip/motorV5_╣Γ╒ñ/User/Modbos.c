#include "stm32f30x.h"
#include "step.h"
#include "buf.h"
#include "Modbos.h"
#include "eeprom.h"
uint8_t addr; //�ӻ���ַ

/*---------------------------------------------------------------------------
����˵����CRC ��λ�ֽ�ֵ��
---------------------------------------------------------------------------*/
 unsigned char const auchCRCHi[] = {

0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,                                                           
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
} ;
/*---------------------------------------------------------------------------
����˵����CRC��λ�ֽ�ֵ��
---------------------------------------------------------------------------*/
 unsigned char const auchCRCLo[] = {

0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06,
0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD,
0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A,
0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 0x14, 0xD4,
0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3,
0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4,
0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29,
0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED,
0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60,
0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67,
0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68,
0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E,
0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71,
0x70, 0xB0, 0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92,
0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B,
0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B,
0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42,
0x43, 0x83, 0x41, 0x81, 0x80, 0x40

};
	
#define ERROR_CRC 0X01;
typedef struct
{
	uint8_t 	newdata; 	//�������ݹ���
	uint8_t 	crc_ok; 	//��ǰ����CRCԭ��
	uint8_t   err;
	uint8_t   function;	//������
	uint16_t 	first_reg;//��ʼ�Ĵ���
	uint32_t   data;
}r_modbus_str;
r_modbus_str r_modbus;
uint8_t r_485_flag;		//485�յ����ݴ����
uint8_t r_485_count;  //�յ���������
/*---------------------------------------------------------------------------
���÷�ʽ��unsigned int CRC16(unsigned char *puchMsg, unsigned int usDataLen)
����˵����CRCУ��
---------------------------------------------------------------------------*/
unsigned int CRC16(unsigned char *puchMsg, uint8_t usDataLen)
{
  unsigned char uchCRCHi = 0xFF ;    // ��CRC�ֽڳ�ʼ�� 
  unsigned char uchCRCLo = 0xFF ;    // ��CRC �ֽڳ�ʼ��
  unsigned uIndex ;                  // CRCѭ���е����� 
  while (usDataLen--)                // ������Ϣ������  
  {
    uIndex = uchCRCHi ^ *puchMsg++ ; // ����CRC         
    uchCRCHi = uchCRCLo ^ auchCRCHi[uIndex] ;
    uchCRCLo = auchCRCLo[uIndex] ;
  }
  return (uchCRCHi << 8 | uchCRCLo) ;
}



uint8_t RS485_RX_BUF[64]; //���ջ������64
uint8_t RS485_RX_CNT = 0; //���յ������ݳ���

void USART_Gpio_Config(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA|RCC_AHBPeriph_GPIOB, ENABLE);
    //RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOB  , ENABLE);
    
    //PB6->TX  PB7->Rx
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource6,GPIO_AF_7);
    GPIO_PinAFConfig(GPIOB,GPIO_PinSource7,GPIO_AF_7);
	
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOA, &GPIO_InitStructure);	
			
	
		 GPIO_ResetBits(GPIOA,GPIO_Pin_12);
}

//uint32_t  GetBaudRate(void)
//{
//	uint32_t baudrateval;
//	RCC_ClocksTypeDef RCC_ClocksStatus;
//	RCC_GetClocksFreq(&RCC_ClocksStatus);
//	baudrateval = RCC_ClocksStatus.USART1CLK_Frequency / USART1->BRR;
//}

uint32_t const baud_rate[10] = {4800,4800,4800,4800,4800,9600,19200,38400,57600,115200};
void USART_Config(void)
{
		//uint32_t temp;
		USART_InitTypeDef USART_InitStructure;
    USART_Gpio_Config();
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	
	
		NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;
    NVIC_InitStructure.NVIC_IRQChannel  = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
        
    NVIC_Init(&NVIC_InitStructure);	
    
		if(motor.baud > 9) motor.baud = 0;
    USART_InitStructure.USART_BaudRate = 115200;//baud_rate[motor.baud];//115200;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    
    USART_Init(USART1,&USART_InitStructure);   
    USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
    USART_ClearFlag(USART3,USART_FLAG_TC);
    USART_Cmd(USART1,ENABLE);
		
		
		addr = motor.addr;
    
		//RS485_TX_EN = 0; //Ĭ��Ϊ����ģʽ
		
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM15 , ENABLE);	
		
//		temp = GetBaudRate();
//		if(temp != 0)
//		{
//			__NOP();
//		}
}


void TIM15_Init(void)
{
		
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
		NVIC_InitTypeDef NVIC_InitStructure; 	
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM15 , ENABLE);
    TIM_DeInit(TIM15);
    TIM_TimeBaseStructure.TIM_Period=2000;		 /* �Զ���װ�ؼĴ������ڵ�ֵ(����ֵ) */
    /* �ۼ� TIM_Period��Ƶ�ʺ����һ�����»����ж� */
    TIM_TimeBaseStructure.TIM_Prescaler= 72;//(22500 - 1);	/* ʱ��Ԥ��Ƶ�� (180M/8)/22500 */
    TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1; 		/* ������Ƶ */
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; /* ���ϼ���ģʽ */
    TIM_TimeBaseInit(TIM15, &TIM_TimeBaseStructure);
    TIM_ClearFlag(TIM15, TIM_FLAG_Update);							/* �������жϱ�־ */
    TIM_ITConfig(TIM15,TIM_IT_Update,ENABLE);
    TIM_Cmd(TIM15, DISABLE);														/* ����ʱ�� */    
    //RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM15 , DISABLE);		/* �ȹرյȴ�ʹ�� */  	
		
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3);  													
    NVIC_InitStructure.NVIC_IRQChannel = TIM1_BRK_TIM15_IRQn;//TIM1_UP_TIM16_IRQn;	  
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);				
		

}


void modbus_init(void)
{
	USART_Gpio_Config();
	TIM15_Init();
	USART_Config();
	r_485_flag = false;
}





void USART_SendStr(uint8_t *str,uint8_t len)
{
	uint32_t i;
    //USART_ITConfig(UART5,USART_IT_RXNE,DISABLE);
  GPIO_SetBits(GPIOA,GPIO_Pin_12);
	
    for(i = 0;i < len;i++)
    {
        while((USART_GetFlagStatus(USART1,USART_FLAG_TXE))!=SET);
        USART_SendData(USART1,*(str+i));
    }
    //while((USART_GetFlagStatus(USARTx,USART_FLAG_TC))!=SET);
		while((USART_GetFlagStatus(USART1,USART_FLAG_TXE))!=SET);
		for(i = 0;i < 2000;i++) __NOP();
    GPIO_ResetBits(GPIOA,GPIO_Pin_12);
    //USART_ITConfig(UART5,USART_IT_RXNE,ENABLE);
}




//���ͼĴ���
void send_reg(uint8_t fun,uint8_t reg,uint32_t val)
{
	uint8_t data[9];
	uint16_t temp;
	
	data[0] = addr;
	data[1] = fun;
	data[2] = reg;
	data[3] = (val >> 24) & 0x00ff;
	data[4] = (val >> 16) & 0x00ff;
	data[5] = (val >> 8) & 0x00ff;
	data[6] = val & 0x00ff;
	temp = CRC16(data,7);
	data[7] = temp >> 8;
	data[8] = temp & 0xff;

	USART_SendStr(data,9);
}

//���մ���
#define RF_STE 	0XA0 	//��״̬
#define CF_AUT	0XC0	//����
#define RF_REG 	0X03	//���Ĵ���
#define WF_REG 	0X06	//д�Ĵ���
void modbus_handle(void)
{
	//uint16_t buf[20];
	uint32_t temp;
	uint16_t crc,r_crc;
	uint8_t *r_buf 	= RS485_RX_BUF;
	uint8_t len 		= r_485_count;
	if(len <= 4) return;
	//ȷ����ַ
	if(r_buf[0] == 0xfe) //ͬ���ź�
	{
		step.sync = 1;
	}
	else if(r_buf[0] == 0xff)	//�޸ĵ�ַ
	{
		if((r_buf[1] == 0xa5) && (r_buf[2] == 0x5a))
		{	//��ַ�޸ĺ�Ҫ������������Ч��
			motor.addr = r_buf[3];
			motor.baud = r_buf[4];
		}		
		else if(r_buf[1] == 0X83)
		{
			temp = 0;
			temp = motor.addr 	<< 24;
			temp |= motor.baud <<16;
			send_reg(RF_STE,0XAF,temp); 
		}
	}
	else if(r_buf[0] == addr)
	{
		r_modbus.newdata = true;
		
		crc  = CRC16(r_buf,len - 2);
		r_crc =  ((uint16_t)r_buf[len-2]  << 8) | r_buf[len-1];
	
		//��֤CRC�������Ƿ���á�
		if(crc == r_crc)
		{
			r_modbus.crc_ok = true;
			r_modbus.function = r_buf[1];
			r_modbus.first_reg =r_buf[2];

			//send_reg();
			if(r_modbus.function == RF_STE)	//���ٶ�
			{
				switch(r_modbus.first_reg)
				{
					case 0xA0: send_reg(RF_STE,0XA0,step.step_current); break; //��ǰλ��
					case 0xA1: send_reg(RF_STE,0XA1,step.status); break;				//��ǰ״̬status		
					

				}
			}
			else if(r_modbus.function == CF_AUT)	//���ٲ���
			{
				switch(r_modbus.first_reg)
				{
					case 0XC0:						//ֹͣ����
						step.stop 	= 1;						
						step.start 	= 0; 
						//step.home = 0;
						break; //��ʱ
					case 0XC3:  
						if(STOP_IN == 0) 
						{	//��ͣ��ť�ָ�������ִ��
							step.stop  = 0; 
							step.start = 1; 
							step.status &= ~ST_STOP;
						}
						break; //��ʼ
					//case 0XC4:	step.home = 1; break; //�ؼ�
					case 0xC5:  step.zero = 1; break; //λ������
					case 0xCA:	//�ر��ŷ�								
								step.servo? (step.servo = 0):(step.servo = 1);	
								break;
					case 0xCD:	
								WriteEEPROMData(); 								
								break;//��������
					
				}
			}
			else if(r_modbus.function == RF_REG) //���Ĵ���
			{
				switch(r_modbus.first_reg)
				{
					case 0x10: send_reg(RF_REG,10,motor.max_current); break;
					case 0x11: send_reg(RF_REG,11,motor.min_current); break;
					case 0x12: send_reg(RF_REG,12,motor.accel); break;
					case 0x13: send_reg(RF_REG,13,motor.in_mode); break;
					case 0x14: send_reg(RF_REG,14,motor.max_step); break;
					case 0x15: send_reg(RF_REG,15,motor.min_step); break;
					case 0x16: send_reg(RF_REG,16,motor.max_speed); break;
					case 0x17: send_reg(RF_REG,17,motor.min_speed); break;
					case 0x18: 
							temp = 0;
							temp = motor.step_mode & 0x3;
							temp |= (motor.decay & 0x3) << 2;
							temp |= (motor.dir & 0x1) << 4;						
							temp |= (motor.ent & 0x1) << 5;	
							send_reg(RF_REG,18,temp); 
							break;
					case 0x19:
							temp = 0;
							temp = 	motor.min_step_error & 0xff;
							temp |= (motor.max_step_error & 0xff) << 8;					
							send_reg(RF_REG,0x19,temp); 
							break;
				}
			}
			else if((r_modbus.function == WF_REG) && (len >= 9)) //д�Ĵ���
			{
					temp = r_buf[3];
					temp <<=8;
					temp |= r_buf[4];
					temp <<=8;
					temp |= r_buf[5];
					temp <<=8;
					temp |= r_buf[6];
					r_modbus.data = temp;
					switch(r_modbus.first_reg)
					{
						case 0x10: 
							if(r_modbus.data < motor.min_current) motor.max_current = motor.min_current;
							motor.max_current 	= r_modbus.data; 
							break;	//4095�ֶ� ���1.4A
						case 0x11: 
							if(r_modbus.data > motor.max_current) motor.min_current = motor.max_current;
							else motor.min_current 	= r_modbus.data; 							
							break; //4095�ֶ� ���1.4A
						case 0x12: motor.accel 				= r_modbus.data; break;
						case 0x13: motor.in_mode 			= r_modbus.data; break;
						case 0x14: 
								if(motor.min_step > r_modbus.data) r_modbus.data =  motor.min_step;								
								motor.max_step	 		= r_modbus.data; 
								break;
						case 0x15: 
								if(motor.max_step < r_modbus.data) r_modbus.data =  motor.max_step;
								motor.min_step 		= r_modbus.data; 
								break;
						case 0x16: 
								motor.max_speed = r_modbus.data;	break;
						case 0x17: 
								motor.min_speed = r_modbus.data;	break;
						case 0x18: 
								motor.step_mode = r_modbus.data & 0x3;
								motor.decay 		= (r_modbus.data>>2) & 0x3;
								motor.dir 			= (r_modbus.data>>4) & 0x1;							
								motor.ent				= (r_modbus.data>>5) & 0x1;							
								break;
						
						case 0x19:
										motor.max_step_error = (r_modbus.data & 0xff00)>>8;
										motor.min_step_error = (r_modbus.data & 0x00ff);
								break;

						
						case 0x40: //Ŀ��Ƕ�
								if(motor.max_step < r_modbus.data) 			r_modbus.data = motor.max_step;
								else if(motor.min_step > r_modbus.data) r_modbus.data = motor.min_step;								
								step.step_target   = r_modbus.data; 
								break; 
					}
			}

			
		}
		else
		{
			r_modbus.crc_ok = false;
			r_modbus.err = ERROR_CRC;
		}
	
	}
	
}



void USART1_IRQHandler(void)
{
    char c;
    if(USART_GetFlagStatus(USART1,USART_FLAG_RXNE)==SET)
    {
				USART_ClearITPendingBit(USART1,USART_IT_RXNE);
        c = USART_ReceiveData(USART1);				
				if(RS485_RX_CNT < 64)
				{
					RS485_RX_BUF[RS485_RX_CNT] = c; 
					RS485_RX_CNT++;
				}				
				else
				{
					RS485_RX_CNT = 0;
				}
				
				TIM_SetCounter(TIM15, 0);
				TIM_Cmd(TIM15, ENABLE);	
        
    }
}

void TIM1_BRK_TIM15_IRQHandler(void)//TIM1_UP_TIM16_IRQHandler(void)
{

	if(TIM_GetITStatus(TIM15,TIM_IT_Update)==SET) //����ж�
	{
		TIM_ClearITPendingBit(TIM15,TIM_IT_Update);  //����жϱ�־λ
		TIM_Cmd(TIM15, DISABLE);					
		//modbus_handle(RS485_RX_BUF,RS485_RX_CNT);
		r_485_flag = true;
		r_485_count = RS485_RX_CNT;
		RS485_RX_CNT = 0;
		__NOP();
	}
	
}
