#ifndef __EEPROM_H
#define __EEPROM_H
#include "stm32f30x.h"

uint8_t MemReadByte(uint16_t *data,uint16_t num);
uint8_t MemWriteByte(uint16_t *data,uint16_t num);
void eeprom_test(void);
uint8_t EEROM_init(uint16_t *val,uint16_t num);

uint8_t WriteEEPROM(uint16_t *data,uint16_t num);

void ReadEEPROMData(void);

void WriteEEPROMData(void);
#endif
