#include "stm32f30x.h"
#include "step.h"
#include "buf.h"
#include <stdio.h>//��׼�Ŀ⺯��
#include <string.h>
#include "Modbos.h"
#include "EEPROM.h"
#define BSRR_VAL (0x0001 << 8)
GPIO_InitTypeDef        GPIO_InitStructure;

void encoder_init_TIM2(void)
{
		TIM_TimeBaseInitTypeDef     TIM_TimeBaseInit_Struc;
    TIM_ICInitTypeDef           TIM_ICInit_Struc;	
		//SYSCFG_EncoderRemapConfig(SYSCFG_EncoderRemap_TIM2);
		RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
		
    TIM_TimeBaseStructInit(&TIM_TimeBaseInit_Struc);
    
    TIM_TimeBaseInit_Struc.TIM_Prescaler=0x01;                 //��ʱ��Ԥ��Ƶ
    TIM_TimeBaseInit_Struc.TIM_Period=2000;              //�趨�������Զ���װֵ
    TIM_TimeBaseInit_Struc.TIM_ClockDivision=TIM_CKD_DIV1; 
    TIM_TimeBaseInit_Struc.TIM_CounterMode=TIM_CounterMode_Up;
    
    TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInit_Struc);
    
    TIM_EncoderInterfaceConfig(TIM2,TIM_EncoderMode_TI12,TIM_ICPolarity_Rising,TIM_ICPolarity_Rising);          //��ʼ��������Tim5ΪTI1���ؼ���
    
    TIM_ICStructInit(&TIM_ICInit_Struc);                         //?????????
    TIM_ICInit_Struc.TIM_ICFilter=3;                            //�����˲���
    
    TIM_ICInit(TIM2,&TIM_ICInit_Struc);
    
    TIM_ClearFlag(TIM2,TIM_FLAG_Update);
    TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
    TIM2->CNT=0;
    TIM_Cmd(TIM2,ENABLE);//������ʱ��5	
}

void gpio_init(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
//  SPI_InitTypeDef  SPI_InitStructure;
      
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA|RCC_AHBPeriph_GPIOB, ENABLE);
 
	

        GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
        GPIO_InitStructure.GPIO_OType=GPIO_OType_OD;
        GPIO_InitStructure.GPIO_Pin=GPIO_Pin_3;//|GPIO_Pin_0;
        GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
        GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;        
        GPIO_Init(GPIOB,&GPIO_InitStructure);	
	
	      GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
        GPIO_InitStructure.GPIO_OType=GPIO_OType_OD;
        GPIO_InitStructure.GPIO_Pin=GPIO_Pin_15;
        GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
        GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;        
        GPIO_Init(GPIOA,&GPIO_InitStructure);	
	
				//GPIO_PinAFConfig(GPIOB,GPIO_PinSource0,GPIO_AF_6);	//PWM
				GPIO_PinAFConfig(GPIOB,GPIO_PinSource3,GPIO_AF_1);
        GPIO_PinAFConfig(GPIOA,GPIO_PinSource15,GPIO_AF_1);//����PA0��PA1Ϊ����ģʽ
        	
        GPIO_InitStructure.GPIO_Mode=GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0;//|GPIO_Pin_0;
        GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
        GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;        
        GPIO_Init(GPIOB,&GPIO_InitStructure);						
	//SPI
		//-CS
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
//  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//  GPIO_Init(GPIOA, &GPIO_InitStructure);	
		//-MOSI,MISO,SCK.
//  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;//PB3~5
//  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;			//
//  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;		//
//  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//50MHz
//  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
//  GPIO_Init(GPIOB, &GPIO_InitStructure);
// 
//	GPIO_PinAFConfig(GPIOB,GPIO_PinSource3,GPIO_AF_6); //PB3����Ϊ SPI3
//	GPIO_PinAFConfig(GPIOB,GPIO_PinSource4,GPIO_AF_6); //PB4����Ϊ SPI3
//	GPIO_PinAFConfig(GPIOB,GPIO_PinSource5,GPIO_AF_6); //PB5����Ϊ SPI3
	//SPI END

	//DC
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;//ģ������
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;//����
		GPIO_Init(GPIOA, &GPIO_InitStructure);//�ٳ�ʼ��GPIO
	//DC END

	//������������
		//RST,-FDT,M1,M0,ENB,DIR,STEP
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_5|GPIO_Pin_3|GPIO_Pin_2|GPIO_Pin_1|GPIO_Pin_0;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
		GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
		GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOA, &GPIO_InitStructure);	
	//������������ END

}  




/**
  * @brief  Configures the System clock source, PLL Multiplier and Divider factors, 
  *         AHB/APBx prescalers and Flash settings
  * @note   This function should be called only once the RCC clock configuration  
  *         is reset to the default reset state (done in SystemInit() function).   
  * @param  None
  * @retval None
  */
void SetSysClock(void)
{
  __IO uint32_t StartUpCounter = 0, HSEStatus = 0;
  
  /* SYSCLK, HCLK, PCLK2 and PCLK1 configuration ---------------------------*/    
  /* Enable HSE */    
  RCC->CR |= ((uint32_t)RCC_CR_HSEON);
 
  /* Wait till HSE is ready and if Time out is reached exit */
  do
  {
    HSEStatus = RCC->CR & RCC_CR_HSERDY;
    StartUpCounter++;  
  } while((HSEStatus == 0) && (StartUpCounter != HSE_STARTUP_TIMEOUT));

  if ((RCC->CR & RCC_CR_HSERDY) != RESET)
  {
    HSEStatus = (uint32_t)0x01;
  }
  else
  {
    HSEStatus = (uint32_t)0x00;
  }  

  if (HSEStatus == (uint32_t)0x01)
  {
    /* Enable Prefetch Buffer and set Flash Latency */
    FLASH->ACR = FLASH_ACR_PRFTBE | FLASH_ACR_LATENCY_1;
    /* HCLK = SYSCLK */
		
    RCC->CFGR |= (uint32_t)RCC_CFGR_HPRE_DIV2;//RCC_CFGR_HPRE_DIV1;
      
    /* PCLK2 = HCLK */
    RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE2_DIV1;
    
    /* PCLK1 = HCLK */
    RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE1_DIV2;
    
   
    /*  PLL configuration: PLLCLK = HSE * 9 = 72 MHz */
    RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_PLLSRC | RCC_CFGR_PLLXTPRE |
                                        RCC_CFGR_PLLMULL));
		//�⾧��16M��PLL�Ŵ�9������144M��Ȼ��SYSCLK/2 =144M��2 = 72M.
    RCC->CFGR |= (uint32_t)(RCC_CFGR_PLLSRC_PREDIV1 | RCC_CFGR_PLLMULL9);

    /* Enable PLL */
    RCC->CR |= RCC_CR_PLLON;
    
    /* Wait till PLL is ready */
    while((RCC->CR & RCC_CR_PLLRDY) == 0)
    {
    }
    
    /* Select PLL as system clock source */
    RCC->CFGR &= (uint32_t)((uint32_t)~(RCC_CFGR_SW));
    RCC->CFGR |= (uint32_t)RCC_CFGR_SW_PLL;    
    
    /* Wait till PLL is used as system clock source */
    while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS) != (uint32_t)RCC_CFGR_SWS_PLL)
    {
    }
  }
  else
  { /* If HSE fails to start-up, the application will have wrong clock 
         configuration. User can add here some code to deal with this error */
  }
}



int no_fi;
extern step_str 	step;
extern int ang_val,no_fi;
extern motor_str motor;
int get_angle(uint8_t);
void  AS5047_SPI_Init (void);
uint16_t SSP_Read_reg(uint16_t reg_add);
unsigned int Lin(unsigned int IN);
unsigned int test(unsigned int in);
unsigned int Lin2(unsigned int IN);
void sep_dir(uint8_t dir);

//uint32_t ti=100,tj=250;
//void delay1(void)
//{
//uint32_t i,j;
//	for(i = 0;i < ti;i++)
//	for(j = 0;j < tj;j++);
//}


void delay2(void)
{
	uint16_t j;
	for(j = 0;j < 0x100;j++);
}
extern step_str 	step;

uint8_t sep_count = 0;
uint8_t sep_count_max = 0;

uint8_t st = 0;
void ang_test(void)
{
	int e;
	if(st == 0)
	{
		step.step_current = TIM_GetCounter(TIM2);
		
		e = step.step_target - step.step_current;
		if(e != 0)
		{
			if(e > 0)
			{
				sep_dir(0);
				//sep_count_max = buf1[step.step_current ];
				sep_count_max >>=1;
				st = 1;
			}
			else
			{
				sep_dir(1);
				//sep_count_max = buf1[step.step_current ];
				sep_count_max >>=1;
				st = 1;
			}
		}
	}
	else
	{
			if(sep_count >= 2)
			{
				sep_count = 0;
				st = 0;
			}
			else
			{
				sep_count++;
				SEP_STEP(1);
				delay2();
				SEP_STEP(0);
				delay2();
			}
	}
	
	
}

//void USART_Gpio_Config(void)
//{
//    GPIO_InitTypeDef GPIO_InitStructure;
//    
//    //RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOB  , ENABLE);
//    
//    //PB6->TX  PB7->Rx
//    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
//    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//    GPIO_Init(GPIOB, &GPIO_InitStructure);
//    
//    GPIO_PinAFConfig(GPIOB,GPIO_PinSource6,GPIO_AF_7);
//    GPIO_PinAFConfig(GPIOB,GPIO_PinSource7,GPIO_AF_7);
//}

//void USART_Config(void)
//{
//	USART_InitTypeDef USART_InitStructure;
//    USART_Gpio_Config();
//    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
//	
//	
//		NVIC_InitTypeDef NVIC_InitStructure;
//    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
//    
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x03;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x02;
//    NVIC_InitStructure.NVIC_IRQChannel  = USART1_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//        
//    NVIC_Init(&NVIC_InitStructure);	
//    
//    USART_InitStructure.USART_BaudRate = 115200;
//    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
//    USART_InitStructure.USART_StopBits = USART_StopBits_1;
//    USART_InitStructure.USART_Parity = USART_Parity_No;
//    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
//    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
//    
//    USART_Init(USART1,&USART_InitStructure);   
//    USART_ITConfig(USART1,USART_IT_RXNE,ENABLE);
//    
//    USART_Cmd(USART1,ENABLE);
//    
//}

//void USART1_IRQHandler(void)
//{
//    char c;
//    if(USART_GetFlagStatus(USART1,USART_FLAG_RXNE)==SET)
//    {
//        c = USART_ReceiveData(USART1);
//        USART_SendData(USART1,c);
//    }
//        //while(1);
//}

/*************************************************
Function: void USART6_Puts(char * str) 
Description: USART6��������            
Input: ����������ָ��                  
Output:��                              
Return:��                              
*************************************************/
//void USART6_Puts(char * str)
//{
// while (*str)
// {
//	USART_SendData(USART1, *str++);

// /* Loop until the end of transmission */
//	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); //���Ӣ�Ĳο���521ҳ����TXE������ʱ��һ֡���ݴ������
// }
//}

//void USART6_send_data(uint16_t id,uint8_t data)
//{
//	if(data > 99) data = 99;
// char h = ((data/10)%10)+'0';
// char L = (data % 10)+'0';
// USART_SendData(USART1,((id/1000)%10)+'0');while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); 
// USART_SendData(USART1,((id/100)%10)+'0');while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); 
// USART_SendData(USART1,((id/10)%10)+'0');while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); 
// USART_SendData(USART1,((id)%10)+'0');while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); 
// USART_SendData(USART1,':');while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); 
// USART_SendData(USART1,h);	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); 
// USART_SendData(USART1,L);	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); 
// USART_SendData(USART1,',');while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); 
// USART_SendData(USART1,'\n');while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET); 
//}

//uint8_t buf1[4000];
//void test1(void)
//{
//	uint32_t 	i,j;
//	static uint8_t 	count;
//	static uint16_t  blo,newd,err;
//	SEP_DIR(0);
//	USART6_Puts("��ʼ����\r\n");
//	blo = TIM_GetCounter(TIM2);
//	//ȥ����ʼλ��
////	for(i = 0;i < 25600;i++)  
////	{
////		SEP_STEP(1);
////		delay1();
////		SEP_STEP(0);
////		delay1();		
////		newd = TIM_GetCounter(TIM2);
////		if(blo != newd) 
////		{
////			blo = newd;
////			break;
////		}
////	}	
//	//����
//	for(j = 0;j < 2;j++)
//	{
//		for(i = 0;i < 25600;i++)  
//		{
//			SEP_STEP(1);
//			delay1();
//			SEP_STEP(0);
//			delay1();		
//			
//			count++;		
//			if(count > 250)
//			{
//				__NOP();
//			}
//			newd = TIM_GetCounter(TIM2);
//			if(blo != newd)
//			{			
//				if(blo > newd) 	err = blo - newd;
//				else 						err = newd - blo;
//				if(err > 1) 
//				{
//					__NOP();
//				}
//				//buf1[newd] = count;
//				USART6_send_data(newd,count);
//				blo = newd;
//				count = 0;
//				if(newd == 0) 
//				{
//					__NOP();
//				}
//			}
//		}		
//	}
//	

//	
//}


//TIM1 PWM���ֳ�ʼ��   
//PWM�����ʼ��  
//arr���Զ���װֵ  
//psc��ʱ��Ԥ��Ƶ��  
void TIM1_PWM_Init(u32 arr,u32 psc)  
{                              
    //�˲������ֶ��޸�IO������  
      
    
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;  
    TIM_OCInitTypeDef  TIM_OCInitStructure;  
      
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);    //TIM14ʱ��ʹ��      

        
    TIM_TimeBaseStructure.TIM_Prescaler=psc;  //��ʱ����Ƶ  
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ  
    TIM_TimeBaseStructure.TIM_Period=arr;   //�Զ���װ��ֵ  
    TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;   
      
    TIM_TimeBaseInit(TIM1,&TIM_TimeBaseStructure);//��ʼ����ʱ��14  
      
    //��ʼ��TIM14 Channel1 PWMģʽ      
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //ѡ��ʱ��ģʽ:TIM������ȵ���ģʽ2  
    TIM_OCInitStructure.TIM_OutputNState  = TIM_OutputNState_Enable; //�Ƚ����ʹ��  
		TIM_OCInitStructure.TIM_Pulse = 10;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_Low; //�������:TIM����Ƚϼ��Ե�  
		
		//TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;/*�������״̬1*/
		TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;/**/		

		TIM_OC2Init(TIM1, &TIM_OCInitStructure);  //����Tָ���Ĳ�����ʼ������TIM1 4OC1  
  
    //TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);  //ʹ��TIM14��CCR1�ϵ�Ԥװ�ؼĴ���  
		//TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);  //ʹ��TIM14��CCR1�ϵ�Ԥװ�ؼĴ���  
   
    //TIM_ARRPreloadConfig(TIM1,ENABLE);//ARPEʹ��   
      
    TIM_Cmd(TIM1, ENABLE);  //ʹ��TIM14 
		TIM_CtrlPWMOutputs(TIM1,ENABLE);/*���ʹ��*/
}    

#define CLI()      __set_PRIMASK(1)         //�ر����ж�

#define SEI()     __set_PRIMASK(0)        //�����ж�
int32_t 	target;
uint8_t sw = 0,dir = 0;
uint16_t count_tg = 0;
void tg(void)
{
	if(sw)
	{
		if((step.step_target == 0) && (dir == 0))
		{
			dir = 1;
		}
		else if((step.step_target >= 4000) && (dir == 1))
		{
			dir = 0;
		}
		

		
		if(dir)
		{
			step.step_target++;
		}
		else
		{
			step.step_target--;
		}		

	}
	

}
//int32_t sheep = 2;
//void delay1(void)
//{
//	
//	int32_t i;
//	
//	for(i=0;i< (sheep);i++); //200in16��Ƶ,90in32��Ƶ,50in62��Ƶ,25in128
//	
//}

void Motor_status(void)
{
//	(err.l_l)? (step.status |= ST_RL):(step.status &= ~ST_RL);
//	(err.r_l)? (step.status |= ST_LL):(step.status &= ~ST_LL);
//	(err.stop)? (step.status |= ST_STOP):(step.status &= ~ST_STOP);
	
		if(step.servo == 0) 
		{
			SEP_ENB(0);
			step.status &= ~ST_SERVE;
		}
		else
		{
			step.status |= ST_SERVE;
			SEP_ENB(1);
		}
		if(STOP_IN) 
		{
						step.status |= ST_STOP;
						step.stop 	= 1;						
						step.start 	= 0; 
						//step.home = 0;
		}
		
		if(R_LIMIT) 	step.status |= ST_RL;		//�������
		else 					step.status &= ~ST_RL;		
		if(L_LIMIT)		step.status |= ST_LL;		//�������
		else 					step.status &= ~ST_LL;		
}

int32_t step_ = 0;
void motor_set_microsteps(uint8_t segme,uint8_t decay);
extern int16_t a_v;
int main(void)
{
	
//	uint16_t buf[10];
//	uint8_t temp;

	SetSysClock();
	SystemCoreClockUpdate();


	gpio_init();
	
	SEP_REST(0);
	
	ReadEEPROMData();
	modbus_init();
	motor_io_init();
	encoder_init_TIM2();
	SEP_REST(1);
//	for(temp = 0;temp < 10 ;temp++)
//{
//buf[temp] = temp;
//}
//temp = 0;
//temp = WriteEEPROM(buf,10);
//if(temp == 0)
//{
//__NOP();
//}
  for (;;)
  {
		

//		Motor_status();
//		if((step_ > motor.max_step_error) || (step_ < -motor.min_step_error))
//		{
//			step.status &= ~ST_TARGET;	//δ�ﵽĿ��ֵ
//			if((((R_LIMIT == 0)&&(step.dir == 0)) || ((L_LIMIT == 0)&&(step.dir !=0))) && step.servo && (step.stop == 0)) //��λ���,�ŷ��򿪼��
//			{							
//				DAC_SetChannel1Data(DAC1,DAC_Align_12b_R,a_v);	
//				SEP_STEP(0);
//				delay1();
//				SEP_STEP(1);
//				delay1();
//			}
//			else
//			{

//				DAC_SetChannel1Data(DAC1,DAC_Align_12b_R,motor.min_current);	
//			}
//		}		
//		else
//		{
//			DAC_SetChannel1Data(DAC1,DAC_Align_12b_R,motor.min_current);	
//			SEP_STEP(0);
//			step.status |= ST_TARGET;	//����Ŀ��ֵ���
//			__NOP();
//		}

		if(r_485_flag == true)
		{
			modbus_handle();
			r_485_flag = false;
		}



  }
}
