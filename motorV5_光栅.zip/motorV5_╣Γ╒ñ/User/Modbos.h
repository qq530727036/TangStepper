#ifndef __Modbos_h

#define __Modbos_h
#include "stm32f30x.h"



#define yes 1
#define no  0
#define true 	1
#define false 0	

extern uint8_t r_485_flag;
void modbus_init(void);
void modbus_handle(void);
#endif
