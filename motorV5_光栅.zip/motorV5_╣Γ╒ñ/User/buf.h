#ifndef buf_h_
#define buf_h_
#include "stm32f30x.h"
//    GPIOA->BSRR = BSRR_VAL;
//    /* Reset PE14 and PE15 */
//    GPIOA->BRR = BSRR_VAL;

//#define IN_DIR_BIT 		GPIO_Pin_12
#define IN_STEP_BIT 	GPIO_Pin_0		//B
#define IN_ENB_BIT 		GPIO_Pin_11



#define SEP_DIR_BIT 	GPIO_Pin_1
#define SEP_STEP_BIT 	GPIO_Pin_2
#define SEP_ENB_BIT 	GPIO_Pin_0
#define SEP_MO0_BIT 	GPIO_Pin_3
#define SEP_MO1_BIT 	GPIO_Pin_5
#define SEP_REST_BIT 	GPIO_Pin_0
#define SEP_FDT_BIT 	GPIO_Pin_6

#define READ_ENB_PIN()    ((GPIOA->IDR & SEP_ENB_BIT) == SEP_ENB_BIT)

#define SEP_DIR(a)		a?(GPIOA->BRR = SEP_DIR_BIT):(GPIOA->BSRR = SEP_DIR_BIT)//����
//#define SEP_STEP(a)		a?(GPIOA->BSRR = SEP_STEP_BIT):(GPIOA->BRR = SEP_STEP_BIT)//����
#define SEP_STEP(a)		a?(GPIOA->BSRR = SEP_STEP_BIT):(GPIOA->BRR = SEP_STEP_BIT)//����
#define SEP_ENB(a)		a?(GPIOA->BSRR = SEP_ENB_BIT):(GPIOA->BRR = SEP_ENB_BIT)//ʹ��
#define SEP_MO1(a)		a?(GPIOA->BSRR = SEP_MO1_BIT):(GPIOA->BRR = SEP_MO1_BIT)//ϸ��
#define SEP_MO0(a)		a?(GPIOA->BSRR = SEP_MO0_BIT):(GPIOA->BRR = SEP_MO0_BIT)//ϸ��
#define SEP_FDT(a)		a?(GPIOA->BSRR = SEP_FDT_BIT):(GPIOA->BRR = SEP_FDT_BIT)//˥��ģʽ
#define SEP_REST(a)		a?(GPIOB->BSRR = SEP_REST_BIT):(GPIOB->BRR = SEP_REST_BIT)//��λ


//����
#define IN_S_1	((GPIOA->IDR & GPIO_Pin_7) == 0)		//��������
#define IN_S_2	((GPIOA->IDR & GPIO_Pin_8) == 0)		//��������
#define IN_E_1	((GPIOA->IDR & GPIO_Pin_11) == 0)		//��������

#define R_LIMIT IN_S_1	//����λ
#define L_LIMIT IN_S_2	//����λ
#define STOP_IN IN_E_1	//ֹͣ

typedef union{
				uint8_t byte[4];
				float floatTemp;
				}float_byte_un;

typedef union{
				uint8_t byte[4];
				uint32_t uint32Temp;
				}uint32_byte_uni;

typedef union{
				uint8_t byte[2];
				uint16_t uint16Temp;
}uint16_byte_uni;		

typedef union{
				uint8_t byte[4];
				int32_t int32Temp;
				}int32_byte_uni;

typedef union{
				uint8_t byte[2];
				int16_t int16Temp;
}int16_byte_uni;	

extern float_byte_un float_byte;
extern uint32_byte_uni uint32_byte;
extern uint16_byte_uni uint16_byte;
extern int32_byte_uni int32_byte;
extern int16_byte_uni int16_byte;



typedef struct  {
	int step;
	int step_all;
}buf_str;






uint8_t serial_available(void);
buf_str *serial_read(void);
void store_char(int step,int step_num);
buf_str *serial_r_buf(uint8_t sw);

#endif
