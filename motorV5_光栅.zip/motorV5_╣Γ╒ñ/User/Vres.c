#include	"LPC11xx.H"

#define PWM_CYCLE  1024





//PWMռ�ձ�
//����ֵΪ100-1
void pwm_Duty_ratio(uint8_t ratio)
{	
	uint32_t cycle;
	if(ratio > 99) ratio = 99;
	if(ratio < 1) ratio =  1;
	ratio = 100 - ratio;
	cycle = (PWM_CYCLE * ratio) / 100;
	LPC_TMR32B0->MR0 = cycle;
	LPC_TMR32B0->MR1 = cycle;
}




void Vres_PWM_Init(void)             //  CT32B0  MAT0:50%,50KHz,MAT1:70%,50KHz
{

				LPC_IOCON->PIO0_1	 = (LPC_IOCON->PIO0_1 & 0XF8) | 0X02;//Selects function CT32B0_MAT0.
				//LPC_IOCON->PIO1_7  = (LPC_IOCON->PIO1_7 & 0XF8) | 0X02;
         LPC_SYSCON->SYSAHBCLKCTRL |= (1<<9);     				//�򿪹���ʱ��
         LPC_TMR32B0->TCR		=0x02;                       //��λ��ʱ��
         LPC_TMR32B0->MR2   =0;                          //ռ�ձ�
				 //LPC_TMR32B0->MR1   =0; 
         LPC_TMR32B0->PWMC  =0x04;                       //ѡ��PWM����
         LPC_TMR32B0->PR    =1;                         //��Ƶ,48000000/48 = 1us
         LPC_TMR32B0->MR3   =PWM_CYCLE;                        //ռ�ձ�����
         //LPC_TMR32B0->EMR   =0x00;                       //01=L,02=H,03=??
        LPC_TMR32B0->MCR = (1<<10);                      //MR3��TCƥ��ʱTC��λ
	
				pwm_Duty_ratio(60);
	
				LPC_TMR32B0->IR 	= 0;   										//��λ�жϱ�־
				LPC_TMR32B0->TCR 	= 0x0001;		//�򿪶�ʱ��	
}


void time_on(void)
{
	LPC_TMR32B0->TC 	= 0;	//�������
	LPC_TMR32B0->TCR 	|= 0x0001;		//�򿪶�ʱ��	
}

void time_off(void)
{
	LPC_TMR32B0->TCR 	= 0;		//�򿪶�ʱ��
}

//ratio ռ�ձ�
//cycle ���� 
//����ʱ��Ϊ0.001ms������ʱ,cycle��λΪ0.001ms
void set_pwm(uint32_t cycle)
{

	LPC_TMR32B0->MR2 = (cycle >> 1) ;
	LPC_TMR32B0->MR3 = cycle;	
}



void  Vres_out(uint32_t value)
{
		if(value >= PWM_CYCLE)
		{
			value = PWM_CYCLE - 1;
		}
		

		LPC_TMR32B0->MR2 = PWM_CYCLE - value;

}


