#include "stm32f30x.h"
#include <stdlib.h>
#include <math.h>
#define IIR_NSEC  5
const double IIR_B[IIR_NSEC][3] = {
        {0.0005452336627,             0,              0 },
  {              1,              2,              1}, 
  {0.0005319133052,              0 ,             0}, 
  {              1,              2,              1}, 
  {              1,              0,              0}
};
            
const double IIR_A[IIR_NSEC][3] = {
                                                                {1,              0,              0 },
                {1,   -1.962403774,   0.9645847082 },
                {1,              0,              0 },
                {1,   -1.914461136,   0.9165887237 },
                {1,              0,              0 }
                                };

static double Y[IIR_NSEC][3];
static double X[IIR_NSEC+1][3];
unsigned int Lin2(unsigned int IN)
{
        unsigned char I;
        unsigned int data;
        X[0][0] = IN;
        for(I = 0;I < IIR_NSEC;I++)
        {
                Y[I][0] = X[I][0]*IIR_B[I][0]+X[I][1]*IIR_B[I][1]+X[I][2]*IIR_B[I][2]\
                                  -Y[I][1]*IIR_A[I][1]-Y[I][2]*IIR_A[I][2];
                Y[I][2] = Y[I][1];
                Y[I][1] = Y[I][0];
                X[I][2] = X[I][1];
                X[I][1] = X[I][0];      
                
                X[I+1][0] = Y[I][0];
        }
        
        //????
				
				if(X[IIR_NSEC-1][0] < 0)
				{
					data = 0;
				}
				else
				{
					data = (unsigned int)X[IIR_NSEC-1][0];
				}
        return data;
        //return ((unsigned int)X[IIR_NSEC-1][0]);
}
